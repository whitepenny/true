<?php 
/*
Plugin Name: S3 Uploads
Description: Store uploads in S3
Author: Human Made Limited
Version: 1.0
Author URI: http://hmn.md
*/
require_once '/usr/share/php/wpengine/s3-uploads/plugin/s3-uploads.php';
