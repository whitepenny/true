<div class="wpe-notices updated wpe-notices-<?php echo $class; ?>" title="<?php echo $id; ?>">
	<p class="wpe-notices-<?php echo $class; ?>">
		<strong><?php echo ucwords( $class ); ?>: </strong><?php _e($message,'wpengine'); ?>
	</p>
</div>
