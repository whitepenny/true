
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<div class="entry-header-inner grid1060">
			<?php
				//variables
				$headerintrotext = get_field('header_intro_text');
			?>
			<h1 class="entry-title headline-style-1"><?php the_title(); ?></h1>
			<?php if( $headerintrotext ): ?>
				<div class="header-intro-text"><?php echo $headerintrotext; ?></div>
			<?php endif; ?>
		</div>
	</header><!-- .entry-header -->

	<div class="entry-content">
		<div class="client-overview-arrow"></div>
		<div class="client-overview-container">


		<?php
		$args = array (
			'post_type' => 'client',
			'order'  => 'DSC',
		);

		$clientquery = new WP_Query( $args );

		if( $clientquery->have_posts() ) : ?>
			<?php while( $clientquery->have_posts() ): $clientquery->the_post(); 

				//variables
				$clientarchiveimage = get_field('client_overview_image');
				$clientarchivelogo = get_field('client_overview_logo');
			?>

			<a href="<?php the_permalink(); ?>" class="the-archived-client-link">
				<div class="the-archived-client" <?php if( $clientarchiveimage ) : ?>style="background-image: url(<?php echo $clientarchiveimage; ?>);"<?php endif;?>>
					<?php if( $clientarchivelogo ) : ?>
						<div class="client-overview-logo"><img src="<?php echo $clientarchivelogo; ?>" alt="logo" /></div>
					<?php endif; ?>
				</div>
			</a>

			<?php endwhile; ?>
		<?php endif; ?>

		</div>
		
	</div><!-- .entry-content -->

</article><!-- #post-## -->
