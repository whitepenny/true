<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <div class="entry-header-inner grid1060">
            <?php
                //variables
                $headerintrotext = get_field('header_intro_text');
            ?>

            <h1 class="entry-title headline-style-1"><?php the_title(); ?></h1>
            <?php if( $headerintrotext ): ?>
                <div class="header-intro-text"><?php echo $headerintrotext; ?></div>
            <?php endif; ?>
        </div>
    </header><!-- .entry-header -->

    <div class="entry-content">
        <?php
            $featured_team = new WP_Query(array(
            'post_type' => 'team-member',
            'cat' => '3',
            ) );
        ?>

        <div class="team-overview-featured">
            <?php while ($featured_team->have_posts()) : $featured_team->the_post(); ?>
                <?php
                    //variables
                    $bwfeatured = get_field('bw_founder_large_photo');
                    $tmt = get_field('team_member_title');
                ?>

                <div class="featured-team-member lazy" style="<?php if( $bwfeatured ) : ?> background-image: url(<?php echo $bwfeatured; endif; ?>);">
                    <!--<a href="<?php the_permalink();?>" class="no-uline team-wrap-link">-->
                        <a href="<?php the_permalink();?>" class="featured-red-mask"></a>
                        <div class="featured-team-member-mask grid-team-member-mask">
                            <div class="team-close"><i class="fa fa-remove"></i></div>
                            <div class="information-container">
                                <h2 class="headline-style-7"><?php the_title(); ?></h2>
                                <?php if( $tmt ) : ?><span class="team-overview-team-title"><?php echo $tmt; ?></span><?php endif; ?>
                                <a href="<?php the_permalink();?>" class="red-button">View Profile</a>
                            </div>
                        </div>
                    <!--</a>-->
                </div>
                <h2 class="headline-style-7 mobile-title"><a href="<?php the_permalink(); ?>" class="no-uline"><?php the_title(); ?></a></h2>

            <?php endwhile; ?>
            <?php wp_reset_postdata(); ?>
        </div>

        <div class="team-overview-grid">
        <?php
            $thepartners = new WP_Query(array(
            'post_type' => 'team-member',
            'cat' => '32',
            'posts_per_page' => 500,
            'orderby' => 'meta_value title',
            'meta_key' => 'last_name',
            'order' => 'ASC',
            ) );

        ?>

        <!--Partners-->
            <?php while ($thepartners->have_posts()) : $thepartners->the_post(); ?>

                <?php
                    //variables
                    $bwphoto = get_field('bw_team_member_photo');
                    $tmtitle = get_field('team_member_title');
                ?>

                <div class="grid-team-member lazy" style="<?php if( $bwphoto ) : ?> background-image: url(<?php echo $bwphoto; endif; ?>);">
                    <!--<a href="<?php the_permalink();?>" class="no-uline team-wrap-link">-->
                        <a href="<?php the_permalink();?>" class="grid-red-mask"></a>
                        <div class="grid-team-member-mask">
                            <div class="team-close"><i class="fa fa-remove"></i></div>
                            <div class="information-container">
                                <h2 class="headline-style-7"><?php the_title(); ?></h2>
                                <?php if( $tmtitle ) : ?><span class="team-overview-team-title"><?php echo $tmtitle; ?></span><?php endif; ?>
                                <a href="<?php the_permalink();?>" class="red-button">View Profile</a>
                            </div>
                        </div>
                    <!--</a>-->
                </div>
                <h2 class="headline-style-7 mobile-title"><a href="<?php the_permalink(); ?>" class="no-uline"><?php the_title(); ?></a></h2>
            <?php endwhile; ?>

            <?php wp_reset_postdata(); ?>

            <?php
            $restof_team = new WP_Query(array(
            'post_type' => 'team-member',
            'cat' => '-3, -32',
            'posts_per_page' => 1000,
            'orderby' => 'meta_value title',
            'meta_key' => 'last_name',
            'order' => 'ASC',
            ) );

        ?>

        <!--Other-->
            <?php while ($restof_team->have_posts()) : $restof_team->the_post(); ?>

                <?php
                    //variables
                    $bwphoto = get_field('bw_team_member_photo');
                    $tmtitle = get_field('team_member_title');
                ?>

                <div class="grid-team-member lazy" style="<?php if( $bwphoto ) : ?> background-image: url(<?php echo $bwphoto; endif; ?>);">
                    <!--<a href="<?php the_permalink();?>" class="no-uline team-wrap-link">-->
                        <a href="<?php the_permalink();?>" class="grid-red-mask"></a>
                        <div class="grid-team-member-mask">
                            <div class="team-close"><i class="fa fa-remove"></i></div>
                            <div class="information-container">
                                <h2 class="headline-style-7"><?php the_title(); ?></h2>
                                <?php if( $tmtitle ) : ?><span class="team-overview-team-title"><?php echo $tmtitle; ?></span><?php endif; ?>
                                <a href="<?php the_permalink();?>" class="red-button">View Profile</a>
                            </div>
                        </div>
                    <!--</a>-->
                </div>
                <h2 class="headline-style-7 mobile-title"><a href="<?php the_permalink(); ?>" class="no-uline"><?php the_title(); ?></a></h2>
            <?php endwhile; ?>

            <?php wp_reset_postdata(); ?>

        </div>

    </div><!-- .entry-content -->
</article><!-- #post-## -->